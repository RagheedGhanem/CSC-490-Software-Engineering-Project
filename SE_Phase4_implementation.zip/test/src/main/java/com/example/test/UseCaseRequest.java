package com.example.test;

public class UseCaseRequest {
    private String useCase;

    public String getUseCase() {
        return useCase;
    }

    public void setUseCase(String useCase) {
        this.useCase = useCase;
    }
}